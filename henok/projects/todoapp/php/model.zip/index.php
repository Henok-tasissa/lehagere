<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials: true');
?>