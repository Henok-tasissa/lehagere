<?php
$conn = new Mysqli("localhost","root","","todoapp");
if($conn->connect_errno){
    die("Connection Error");
}
?>